import { AppData, Section, ApiResponse } from '../types';

export const api = {
  // Приложения
  async getUserApps(userId: string): Promise<ApiResponse<AppData[]>> {
    const apps = localStorage.getItem('apps');
    return {
      success: true,
      data: apps ? JSON.parse(apps) : []
    };
  },

  async createApp(app: AppData): Promise<ApiResponse<AppData>> {
    const apps = localStorage.getItem('apps');
    const currentApps = apps ? JSON.parse(apps) : [];
    currentApps.push(app);
    localStorage.setItem('apps', JSON.stringify(currentApps));
    return {
      success: true,
      data: app
    };
  },

  async updateApp(app: AppData): Promise<ApiResponse<AppData>> {
    const apps = localStorage.getItem('apps');
    if (apps) {
      const currentApps = JSON.parse(apps);
      const updatedApps = currentApps.map((a: AppData) => 
        a.id === app.id ? app : a
      );
      localStorage.setItem('apps', JSON.stringify(updatedApps));
    }
    return {
      success: true,
      data: app
    };
  },

  async updateAppsOrder(apps: AppData[]): Promise<ApiResponse<AppData[]>> {
    localStorage.setItem('apps', JSON.stringify(apps));
    return {
      success: true,
      data: apps
    };
  },

  async deleteApp(appId: string): Promise<ApiResponse<void>> {
    const apps = localStorage.getItem('apps');
    if (apps) {
      const currentApps = JSON.parse(apps).filter((app: AppData) => app.id !== appId);
      localStorage.setItem('apps', JSON.stringify(currentApps));
      // Удаляем также все разделы приложения
      localStorage.removeItem(`sections_${appId}`);
    }
    return { success: true };
  },

  // Разделы
  async getAppSections(appId: string): Promise<ApiResponse<Section[]>> {
    const sections = localStorage.getItem(`sections_${appId}`);
    return {
      success: true,
      data: sections ? JSON.parse(sections) : []
    };
  },

  async createSection(appId: string, section: Section): Promise<ApiResponse<Section>> {
    const sections = localStorage.getItem(`sections_${appId}`);
    const currentSections = sections ? JSON.parse(sections) : [];
    currentSections.push(section);
    localStorage.setItem(`sections_${appId}`, JSON.stringify(currentSections));
    return {
      success: true,
      data: section
    };
  },

  async updateSection(appId: string, section: Section): Promise<ApiResponse<Section>> {
    const sections = localStorage.getItem(`sections_${appId}`);
    if (sections) {
      const currentSections = JSON.parse(sections).map((s: Section) =>
        s.id === section.id ? section : s
      );
      localStorage.setItem(`sections_${appId}`, JSON.stringify(currentSections));
    }
    return {
      success: true,
      data: section
    };
  },

  async deleteSection(appId: string, sectionId: string): Promise<ApiResponse<void>> {
    const sections = localStorage.getItem(`sections_${appId}`);
    if (sections) {
      const currentSections = JSON.parse(sections).filter((s: Section) => s.id !== sectionId);
      localStorage.setItem(`sections_${appId}`, JSON.stringify(currentSections));
    }
    return { success: true };
  },

  async updateSectionsOrder(appId: string, sections: Section[]): Promise<ApiResponse<Section[]>> {
    localStorage.setItem(`sections_${appId}`, JSON.stringify(sections));
    return {
      success: true,
      data: sections
    };
  }
};