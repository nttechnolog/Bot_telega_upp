import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HomeScreen } from './screens/HomeScreen';
import { CreateAppScreen } from './screens/CreateAppScreen';
import { SectionsScreen } from './screens/SectionsScreen';
import { Screen, AppData } from './types';
import { api } from './services/api';

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('home');
  const [isCreating, setIsCreating] = useState(false);
  const [selectedApp, setSelectedApp] = useState<AppData | null>(null);

  const handleCreateApp = async (data: AppData) => {
    const response = await api.createApp(data);
    if (response.success) {
      setIsCreating(false);
      setSelectedApp(response.data!);
    }
  };

  const handleAppClick = (app: AppData) => {
    setSelectedApp(app);
  };

  if (selectedApp) {
    return (
      <SectionsScreen
        onBack={() => setSelectedApp(null)}
        appId={selectedApp.id}
        appName={selectedApp.name}
      />
    );
  }

  if (isCreating) {
    return (
      <CreateAppScreen
        onBack={() => setIsCreating(false)}
        onCreateApp={handleCreateApp}
      />
    );
  }

  return (
    <>
      <HomeScreen 
        onCreateClick={() => setIsCreating(true)}
        onAppClick={handleAppClick}
      />
      <Navigation
        currentScreen={currentScreen}
        onScreenChange={setCurrentScreen}
      />
    </>
  );
}

export default App;