import React from 'react';
import { Star } from 'lucide-react';

export function PremiumBadge({ expiryDate }: { expiryDate: string }) {
  return (
    <div className="bg-purple-800/40 backdrop-blur-sm rounded-lg p-4 border border-purple-500/20">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Star className="w-5 h-5 text-yellow-400 animate-spin-slow" />
          <span className="text-purple-100 font-semibold">Premium</span>
        </div>
        <button className="px-4 py-1 bg-purple-600 hover:bg-purple-500 rounded-full text-sm text-white transition-all">
          Продлить
        </button>
      </div>
      <p className="text-sm text-purple-300 mt-1">Активна до {expiryDate}</p>
    </div>
  );
}