import React from 'react';
import { Bot } from 'lucide-react';

export function Header() {
  return (
    <header className="fixed top-0 w-full bg-purple-900/90 backdrop-blur-lg shadow-lg z-50 border-b border-purple-500/20">
      <div className="container mx-auto px-4 py-3 flex items-center space-x-3">
        <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center animate-pulse">
          <Bot className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">BotPapa</h1>
          <p className="text-sm text-purple-200">Конструктор мини-приложений</p>
        </div>
      </div>
    </header>
  );
}