import React from 'react';
import { Plus } from 'lucide-react';

export function CreateAppButton() {
  return (
    <button className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-500 hover:to-blue-400 text-white rounded-lg p-4 flex items-center justify-center space-x-2 group transition-all duration-300 shadow-lg hover:shadow-purple-500/25">
      <Plus className="w-5 h-5 group-hover:rotate-90 transition-transform duration-300" />
      <span>Создать мини-приложение</span>
    </button>
  );
}