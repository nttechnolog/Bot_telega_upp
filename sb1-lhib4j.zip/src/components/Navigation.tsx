import React from 'react';
import { Home, Box, Star, Menu } from 'lucide-react';
import { Screen } from '../types';

interface NavigationProps {
  currentScreen: Screen;
  onScreenChange: (screen: Screen) => void;
}

export function Navigation({ currentScreen, onScreenChange }: NavigationProps) {
  const navItems: Array<{ name: string; icon: React.ReactNode; screen: Screen }> = [
    { name: 'Главная', icon: <Home className="w-5 h-5" />, screen: 'home' },
    { name: 'Хаб', icon: <Box className="w-5 h-5" />, screen: 'hub' },
    { name: 'Premium', icon: <Star className="w-5 h-5" />, screen: 'premium' },
    { name: 'Ещё', icon: <Menu className="w-5 h-5" />, screen: 'settings' },
  ];

  return (
    <nav className="fixed bottom-0 w-full bg-purple-900/90 backdrop-blur-lg border-t border-purple-500/20">
      <div className="container mx-auto px-4 py-2">
        <div className="flex justify-around">
          {navItems.map(({ name, icon, screen }) => (
            <button
              key={screen}
              onClick={() => onScreenChange(screen)}
              className={`flex flex-col items-center p-2 transition-colors ${
                currentScreen === screen ? 'text-white' : 'text-purple-300'
              }`}
            >
              {icon}
              <span className="text-xs mt-1">{name}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}