import React from 'react';
import { Block } from '../../types';
import { Settings, Trash2 } from 'lucide-react';

interface ConstructorCanvasProps {
  blocks: Block[];
  onBlockEdit: (block: Block) => void;
  onBlockDelete: (blockId: string) => void;
  onDragStart: (block: Block) => void;
  onDragOver: (e: React.DragEvent, block: Block) => void;
}

export function ConstructorCanvas({
  blocks,
  onBlockEdit,
  onBlockDelete,
  onDragStart,
  onDragOver
}: ConstructorCanvasProps) {
  if (blocks.length === 0) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center bg-purple-800/20 rounded-lg border border-purple-500/20">
        <img
          src="https://cdn3.iconfinder.com/data/icons/easter-2090/512/Easter_Egg-16-512.png"
          alt="Empty state"
          className="w-24 h-24 mb-4 opacity-50"
        />
        <p className="text-purple-300">Пока нет ни одного блока</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {blocks.map((block) => (
        <div
          key={block.id}
          draggable
          onDragStart={() => onDragStart(block)}
          onDragOver={(e) => onDragOver(e, block)}
          className="group relative bg-purple-800/30 rounded-lg border border-purple-500/20 p-4 cursor-move hover:bg-purple-700/30 transition-all"
        >
          {/* Превью блока */}
          <div className="min-h-[100px]">
            {block.type === 'text' && (
              <p style={{ ...block.style, ...block.content }}>
                {block.content.text}
              </p>
            )}
            {block.type === 'image' && (
              <img
                src={block.content.url}
                alt={block.content.alt}
                style={{ ...block.style, ...block.content }}
                className="rounded-lg"
              />
            )}
          </div>

          {/* Панель управления */}
          <div className="absolute top-2 right-2 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onBlockEdit(block)}
              className="p-2 bg-purple-600/80 hover:bg-purple-600 rounded-full transition-colors"
            >
              <Settings className="w-4 h-4 text-white" />
            </button>
            <button
              onClick={() => onBlockDelete(block.id)}
              className="p-2 bg-red-500/80 hover:bg-red-500 rounded-full transition-colors"
            >
              <Trash2 className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}