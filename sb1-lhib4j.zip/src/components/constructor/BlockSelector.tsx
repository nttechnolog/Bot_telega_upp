import React from 'react';
import { 
  Type, Image, Button, FormInput, MousePointer, Video,
  HelpCircle, AlignLeft, Minus, ShoppingCart, Share2,
  Images, Music, Map, Timer, Code
} from 'lucide-react';
import { BlockType } from '../../types';

interface BlockSelectorProps {
  onSelect: (type: BlockType) => void;
  onCancel: () => void;
}

interface BlockOption {
  type: BlockType;
  icon: React.ReactNode;
  label: string;
  soon?: boolean;
}

export function BlockSelector({ onSelect, onCancel }: BlockSelectorProps) {
  const blocks: BlockOption[] = [
    { type: 'text', icon: <Type />, label: 'Текст' },
    { type: 'image', icon: <Image />, label: 'Изображение' },
    { type: 'button', icon: <Button />, label: 'Кнопка' },
    { type: 'form', icon: <FormInput />, label: 'Форма' },
    { type: 'mainButton', icon: <MousePointer />, label: 'Главная кнопка' },
    { type: 'auxButton', icon: <Button />, label: 'Доп. кнопка' },
    { type: 'video', icon: <Video />, label: 'Видео' },
    { type: 'faq', icon: <HelpCircle />, label: 'Вопросы и ответы' },
    { type: 'iconText', icon: <AlignLeft />, label: 'Иконки и текст' },
    { type: 'divider', icon: <Minus />, label: 'Разделитель' },
    { type: 'shop', icon: <ShoppingCart />, label: 'Магазин', soon: true },
    { type: 'social', icon: <Share2 />, label: 'Социальные сети', soon: true },
    { type: 'carousel', icon: <Images />, label: 'Карусель', soon: true },
    { type: 'audio', icon: <Music />, label: 'Аудио', soon: true },
    { type: 'map', icon: <Map />, label: 'Карта', soon: true },
    { type: 'timer', icon: <Timer />, label: 'Таймер', soon: true },
    { type: 'code', icon: <Code />, label: 'Код', soon: true }
  ];

  return (
    <div className="fixed inset-0 bg-purple-900/95 backdrop-blur-lg z-50 overflow-y-auto">
      <div className="container mx-auto px-4 py-8">
        <h2 className="text-2xl font-bold text-white mb-8">Добавить новый блок</h2>
        
        <div className="grid grid-cols-2 gap-4">
          {blocks.map(({ type, icon, label, soon }) => (
            <button
              key={type}
              onClick={() => !soon && onSelect(type)}
              className={`
                relative group p-6 bg-purple-800/30 rounded-lg border border-purple-500/20
                flex flex-col items-center justify-center space-y-3
                hover:bg-purple-700/30 transition-all duration-300
                ${soon ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              <div className="w-12 h-12 flex items-center justify-center text-purple-400 group-hover:text-purple-200 transition-colors">
                {icon}
              </div>
              <span className="text-purple-200 group-hover:text-white transition-colors">
                {label}
              </span>
              {soon && (
                <span className="absolute top-2 right-2 text-xs text-purple-400 bg-purple-800/50 px-2 py-1 rounded">
                  Скоро
                </span>
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/0 via-purple-500/5 to-purple-500/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-shimmer" />
            </button>
          ))}
        </div>

        <button
          onClick={onCancel}
          className="fixed bottom-8 left-1/2 -translate-x-1/2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg px-8 py-3 transition-colors"
        >
          Отмена
        </button>
      </div>
    </div>
  );
}