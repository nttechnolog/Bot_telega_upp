import React, { useState } from 'react';
import { ImageBlock } from '../../../types';
import { Upload, Trash2 } from 'lucide-react';

interface ImageBlockEditorProps {
  block: ImageBlock;
  onChange: (block: ImageBlock) => void;
}

export function ImageBlockEditor({ block, onChange }: ImageBlockEditorProps) {
  const [isUploading, setIsUploading] = useState(false);

  const handleContentChange = (key: keyof ImageBlock['content'], value: any) => {
    onChange({
      ...block,
      content: {
        ...block.content,
        [key]: value
      }
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    // Здесь будет загрузка изображения на сервер
    // Пока просто эмулируем задержку
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const reader = new FileReader();
    reader.onloadend = () => {
      handleContentChange('url', reader.result as string);
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Редактор изображения</h2>
        <button className="p-2 hover:bg-purple-700/50 rounded-full transition-colors">
          <Trash2 className="w-6 h-6 text-red-400" />
        </button>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Загрузить изображение
          </label>
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
              id="image-upload"
            />
            <label
              htmlFor="image-upload"
              className={`
                w-full h-40 flex flex-col items-center justify-center
                bg-purple-800/30 border-2 border-dashed border-purple-500/30
                rounded-lg cursor-pointer transition-all
                ${isUploading ? 'opacity-50' : 'hover:border-purple-500/50'}
              `}
            >
              <Upload className={`w-8 h-8 text-purple-400 mb-2 ${isUploading ? 'animate-bounce' : ''}`} />
              <span className="text-purple-200">
                {isUploading ? 'Загрузка...' : 'Нажмите или перетащите файл'}
              </span>
            </label>
          </div>
        </div>

        {block.content.url && (
          <div className="relative">
            <img
              src={block.content.url}
              alt={block.content.alt}
              className="w-full h-40 object-cover rounded-lg"
            />
            <button
              onClick={() => handleContentChange('url', '')}
              className="absolute top-2 right-2 p-2 bg-red-500/80 hover:bg-red-500 rounded-full transition-colors"
            >
              <Trash2 className="w-4 h-4 text-white" />
            </button>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Альтернативный текст
          </label>
          <input
            type="text"
            value={block.content.alt}
            onChange={(e) => handleContentChange('alt', e.target.value)}
            className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
            placeholder="Описание изображения..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Размер изображения
          </label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-purple-300 mb-1">Ширина</label>
              <input
                type="number"
                value={block.content.width}
                onChange={(e) => handleContentChange('width', Number(e.target.value))}
                className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
              />
            </div>
            <div>
              <label className="block text-xs text-purple-300 mb-1">Высота</label>
              <input
                type="number"
                value={block.content.height}
                onChange={(e) => handleContentChange('height', Number(e.target.value))}
                className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
              />
            </div>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Режим отображения
          </label>
          <select
            value={block.content.fit}
            onChange={(e) => handleContentChange('fit', e.target.value)}
            className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
          >
            <option value="cover">Заполнить</option>
            <option value="contain">Вместить</option>
            <option value="fill">Растянуть</option>
          </select>
        </div>
      </div>
    </div>
  );
}