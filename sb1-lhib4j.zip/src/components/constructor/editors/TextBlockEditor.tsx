import React from 'react';
import { TextBlock } from '../../../types';
import { Trash2 } from 'lucide-react';

interface TextBlockEditorProps {
  block: TextBlock;
  onChange: (block: TextBlock) => void;
}

export function TextBlockEditor({ block, onChange }: TextBlockEditorProps) {
  const fontSizes = [12, 14, 16, 18, 20, 24, 28, 32, 36, 48];
  const fontStyles = ['Обычный', 'Жирный', 'Курсив'];
  const alignments = [
    { value: 'left', label: 'По левому краю' },
    { value: 'center', label: 'По центру' },
    { value: 'right', label: 'По правому краю' }
  ];

  const handleContentChange = (key: keyof TextBlock['content'], value: any) => {
    onChange({
      ...block,
      content: {
        ...block.content,
        [key]: value
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Редактор текста</h2>
        <button className="p-2 hover:bg-purple-700/50 rounded-full transition-colors">
          <Trash2 className="w-6 h-6 text-red-400" />
        </button>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Размер шрифта
          </label>
          <select
            value={block.content.fontSize}
            onChange={(e) => handleContentChange('fontSize', Number(e.target.value))}
            className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
          >
            {fontSizes.map(size => (
              <option key={size} value={size}>{size}px</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Стиль шрифта
          </label>
          <select
            value={block.content.fontStyle}
            onChange={(e) => handleContentChange('fontStyle', e.target.value)}
            className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
          >
            {fontStyles.map(style => (
              <option key={style} value={style}>{style}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Выравнивание
          </label>
          <div className="flex space-x-2">
            {alignments.map(({ value, label }) => (
              <button
                key={value}
                onClick={() => handleContentChange('alignment', value)}
                className={`
                  flex-1 py-2 rounded-lg border
                  ${block.content.alignment === value
                    ? 'bg-purple-600 border-purple-500 text-white'
                    : 'bg-purple-800/30 border-purple-500/30 text-purple-200'
                  }
                `}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Цвет текста
          </label>
          <div className="flex space-x-2">
            {['#FFFFFF', '#9CA3AF', '#6B7280', '#4B5563', '#1F2937'].map(color => (
              <button
                key={color}
                onClick={() => handleContentChange('color', color)}
                className={`
                  w-8 h-8 rounded-full border-2
                  ${block.content.color === color
                    ? 'border-purple-400'
                    : 'border-transparent'
                  }
                `}
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-purple-200 mb-2">
            Содержание
          </label>
          <textarea
            value={block.content.text}
            onChange={(e) => handleContentChange('text', e.target.value)}
            className="w-full h-32 bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white resize-none"
            placeholder="Введите текст..."
          />
        </div>
      </div>
    </div>
  );
}