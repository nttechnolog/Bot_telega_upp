import React, { useState } from 'react';
import { Block, TextBlock, ImageBlock } from '../../types';
import { TextBlockEditor } from './editors/TextBlockEditor';
import { ImageBlockEditor } from './editors/ImageBlockEditor';

interface BlockEditorProps {
  block: Block;
  onSave: (block: Block) => void;
  onCancel: () => void;
}

export function BlockEditor({ block, onSave, onCancel }: BlockEditorProps) {
  const [currentBlock, setCurrentBlock] = useState(block);

  const handleSave = () => {
    onSave(currentBlock);
  };

  return (
    <div className="fixed inset-0 bg-purple-900/95 backdrop-blur-lg z-50 overflow-y-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {currentBlock.type === 'text' && (
            <TextBlockEditor
              block={currentBlock as TextBlock}
              onChange={setCurrentBlock}
            />
          )}
          {currentBlock.type === 'image' && (
            <ImageBlockEditor
              block={currentBlock as ImageBlock}
              onChange={setCurrentBlock}
            />
          )}
          
          <div className="flex space-x-4 mt-8">
            <button
              onClick={handleSave}
              className="flex-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg py-3 transition-colors"
            >
              Сохранить
            </button>
            <button
              onClick={onCancel}
              className="flex-1 bg-purple-800/50 hover:bg-purple-700/50 text-white rounded-lg py-3 transition-colors"
            >
              Отмена
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}