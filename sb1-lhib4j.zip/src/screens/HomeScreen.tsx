import React, { useState, useEffect } from 'react';
import { Header } from '../components/Header';
import { PremiumBadge } from '../components/PremiumBadge';
import { CreateAppButton } from '../components/CreateAppButton';
import { MessageSquare, Star, Settings, Trash2 } from 'lucide-react';
import { AppData } from '../types';
import { api } from '../services/api';

interface HomeScreenProps {
  onCreateClick: () => void;
  onAppClick: (app: AppData) => void;
}

export function HomeScreen({ onCreateClick, onAppClick }: HomeScreenProps) {
  const [apps, setApps] = useState<AppData[]>([]);
  const [draggedApp, setDraggedApp] = useState<AppData | null>(null);

  useEffect(() => {
    loadApps();
  }, []);

  const loadApps = async () => {
    const response = await api.getUserApps('current-user'); // В будущем здесь будет реальный ID пользователя
    if (response.success && response.data) {
      setApps(response.data);
    }
  };

  const handleDeleteApp = async (id: string) => {
    if (window.confirm('Вы уверены, что хотите удалить это приложение?')) {
      const response = await api.deleteApp(id);
      if (response.success) {
        setApps(apps.filter(app => app.id !== id));
      }
    }
  };

  const toggleFavorite = async (app: AppData) => {
    const updatedApp = { ...app, isFavorite: !app.isFavorite };
    const response = await api.updateApp(updatedApp);
    if (response.success) {
      setApps(apps.map(a => a.id === app.id ? updatedApp : a));
    }
  };

  const handleDragStart = (app: AppData) => {
    setDraggedApp(app);
  };

  const handleDragOver = async (e: React.DragEvent, targetApp: AppData) => {
    e.preventDefault();
    if (!draggedApp || draggedApp.id === targetApp.id) return;

    const newApps = [...apps];
    const draggedIndex = apps.findIndex(app => app.id === draggedApp.id);
    const targetIndex = apps.findIndex(app => app.id === targetApp.id);

    newApps.splice(draggedIndex, 1);
    newApps.splice(targetIndex, 0, draggedApp);

    const response = await api.updateAppsOrder(newApps);
    if (response.success) {
      setApps(newApps);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-purple-900 text-white">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1636953056323-9c09fdd74fa6')] opacity-10 bg-cover bg-center" />
      <div className="absolute inset-0 bg-purple-900/50 backdrop-blur-sm" />
      
      <Header />

      <main className="container mx-auto px-4 pt-24 pb-16 relative z-10">
        <div className="space-y-6">
          <PremiumBadge expiryDate="14.11.2024" />
          
          <div className="bg-white/5 backdrop-blur-lg rounded-lg p-4 border border-purple-500/20">
            <h2 className="text-lg font-semibold mb-4">ВАШИ МИНИ-ПРИЛОЖЕНИЯ</h2>
            <div className="space-y-4">
              <div onClick={onCreateClick}>
                <CreateAppButton />
              </div>
              
              <div className="space-y-2">
                {apps.map((app) => (
                  <div
                    key={app.id}
                    draggable
                    onDragStart={() => handleDragStart(app)}
                    onDragOver={(e) => handleDragOver(e, app)}
                    className="bg-purple-800/30 rounded-lg p-4 flex items-center justify-between group hover:bg-purple-700/30 transition-all cursor-move"
                    onClick={() => onAppClick(app)}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                        <MessageSquare className="w-4 h-4" />
                      </div>
                      <div>
                        <h3 className="font-medium">{app.name}</h3>
                        <p className="text-sm text-purple-300">@{app.address}</p>
                      </div>
                    </div>
                    <div className="flex space-x-2" onClick={e => e.stopPropagation()}>
                      <button 
                        className="p-2 hover:bg-purple-600/50 rounded-full transition-colors"
                        onClick={() => toggleFavorite(app)}
                      >
                        <Star className={`w-4 h-4 ${app.isFavorite ? 'text-yellow-400 fill-yellow-400' : 'text-purple-400'}`} />
                      </button>
                      <button 
                        className="p-2 hover:bg-purple-600/50 rounded-full transition-colors"
                        onClick={() => handleDeleteApp(app.id)}
                      >
                        <Trash2 className="w-4 h-4 text-purple-400 hover:text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}