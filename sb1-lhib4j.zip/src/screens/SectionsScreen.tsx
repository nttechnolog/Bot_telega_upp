import React, { useState, useEffect } from 'react';
import { ArrowLeft, Plus, Pencil, Eye, Trash2, GripVertical, Bot } from 'lucide-react';
import { Section } from '../types';
import { api } from '../services/api';

interface SectionsScreenProps {
  onBack: () => void;
  appId: string;
  appName: string;
}

export function SectionsScreen({ onBack, appId, appName }: SectionsScreenProps) {
  const [sections, setSections] = useState<Section[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [newSection, setNewSection] = useState({ name: '', slug: '' });
  const [slugError, setSlugError] = useState('');
  const [draggedSection, setDraggedSection] = useState<Section | null>(null);

  useEffect(() => {
    loadSections();
  }, [appId]);

  const loadSections = async () => {
    const response = await api.getAppSections(appId);
    if (response.success && response.data) {
      setSections(response.data);
    }
  };

  const validateSlug = (value: string) => {
    const regex = /^[a-z0-9-]+$/;
    if (!regex.test(value) && value !== '') {
      setSlugError('Допустимы только английские буквы в нижнем регистре, цифры и дефис');
      return false;
    }
    setSlugError('');
    return true;
  };

  const handleSlugChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toLowerCase();
    if (validateSlug(value)) {
      setNewSection({ ...newSection, slug: value });
    }
  };

  const handleAddSection = async () => {
    if (!newSection.name || !newSection.slug) {
      alert('Заполните все обязательные поля');
      return;
    }
    if (!validateSlug(newSection.slug)) {
      return;
    }

    const section: Section = {
      id: crypto.randomUUID(),
      name: newSection.name,
      slug: newSection.slug,
      isActive: true,
      order: sections.length
    };

    const response = await api.createSection(appId, section);
    if (response.success) {
      setSections([...sections, section]);
      setNewSection({ name: '', slug: '' });
      setIsCreating(false);
    }
  };

  const handleDeleteSection = async (sectionId: string) => {
    if (window.confirm('Вы уверены, что хотите удалить этот раздел?')) {
      const response = await api.deleteSection(appId, sectionId);
      if (response.success) {
        setSections(sections.filter(section => section.id !== sectionId));
      }
    }
  };

  const toggleSectionActive = async (section: Section) => {
    const updatedSection = { ...section, isActive: !section.isActive };
    const response = await api.updateSection(appId, updatedSection);
    if (response.success) {
      setSections(sections.map(s => s.id === section.id ? updatedSection : s));
    }
  };

  const handleDragStart = (section: Section) => {
    setDraggedSection(section);
  };

  const handleDragOver = async (e: React.DragEvent, targetSection: Section) => {
    e.preventDefault();
    if (!draggedSection || draggedSection.id === targetSection.id) return;

    const newSections = [...sections];
    const draggedIndex = sections.findIndex(s => s.id === draggedSection.id);
    const targetIndex = sections.findIndex(s => s.id === targetSection.id);

    newSections.splice(draggedIndex, 1);
    newSections.splice(targetIndex, 0, draggedSection);

    // Обновляем порядок
    const updatedSections = newSections.map((section, index) => ({
      ...section,
      order: index
    }));

    const response = await api.updateSectionsOrder(appId, updatedSections);
    if (response.success) {
      setSections(updatedSections);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-purple-900">
      <div className="absolute inset-0 animate-shimmer pointer-events-none" />
      
      <header className="fixed top-0 w-full bg-purple-900/90 backdrop-blur-lg z-50 border-b border-purple-500/20">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={onBack}
                className="p-2 hover:bg-purple-700/50 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-white" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-white">Разделы</h1>
                <p className="text-sm text-purple-200">{appName}</p>
              </div>
            </div>
            <div className="w-12 h-12 relative">
              <Bot className="w-full h-full text-purple-400 animate-spin-slow" />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 pt-24 pb-24">
        <div className="space-y-4">
          {sections.map((section) => (
            <div
              key={section.id}
              draggable
              onDragStart={() => handleDragStart(section)}
              onDragOver={(e) => handleDragOver(e, section)}
              className="bg-purple-800/30 rounded-lg border border-purple-500/20 group hover:bg-purple-700/30 transition-all cursor-move"
            >
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <button className="touch-none p-2 text-purple-400 hover:text-purple-200">
                    <GripVertical className="w-4 h-4" />
                  </button>
                  <div>
                    <h3 className="font-medium text-white">{section.name}</h3>
                    <p className="text-sm text-purple-300">/{section.slug}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    className="p-2 hover:bg-purple-600/50 rounded-full transition-colors"
                    onClick={() => toggleSectionActive(section)}
                  >
                    <Eye className={`w-4 h-4 ${section.isActive ? 'text-green-400' : 'text-purple-400'}`} />
                  </button>
                  <button 
                    className="p-2 hover:bg-purple-600/50 rounded-full transition-colors"
                    onClick={() => handleDeleteSection(section.id)}
                  >
                    <Trash2 className="w-4 h-4 text-purple-400 hover:text-red-400" />
                  </button>
                </div>
              </div>
            </div>
          ))}

          {isCreating ? (
            <div className="bg-purple-800/30 rounded-lg border border-purple-500/20 p-4 space-y-4">
              <div>
                <label className="block text-sm font-medium text-purple-200 mb-2">
                  Название раздела
                </label>
                <input
                  type="text"
                  value={newSection.name}
                  onChange={(e) => setNewSection({ ...newSection, name: e.target.value })}
                  className="w-full bg-purple-700/30 border border-purple-500/30 rounded-lg px-4 py-2 text-white"
                  placeholder="Например: О нас"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-purple-200 mb-2">
                  Адрес раздела
                </label>
                <input
                  type="text"
                  value={newSection.slug}
                  onChange={handleSlugChange}
                  className={`w-full bg-purple-700/30 border ${slugError ? 'border-red-500' : 'border-purple-500/30'} rounded-lg px-4 py-2 text-white`}
                  placeholder="Например: about"
                  required
                />
                {slugError && (
                  <p className="text-sm text-red-400 mt-1">{slugError}</p>
                )}
                <p className="text-sm text-purple-400 mt-1">
                  Может содержать только латинские символы в нижнем регистре, цифры или дефис
                </p>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={handleAddSection}
                  className="flex-1 bg-purple-600 hover:bg-purple-500 text-white rounded-lg py-2 transition-colors"
                >
                  Создать
                </button>
                <button
                  onClick={() => setIsCreating(false)}
                  className="flex-1 bg-purple-800/50 hover:bg-purple-700/50 text-white rounded-lg py-2 transition-colors"
                >
                  Отмена
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setIsCreating(true)}
              className="w-full bg-purple-800/30 hover:bg-purple-700/30 rounded-lg border border-purple-500/20 p-4 flex items-center justify-center space-x-2 group transition-all"
            >
              <Plus className="w-5 h-5 text-purple-400 group-hover:text-purple-200" />
              <span className="text-purple-400 group-hover:text-purple-200">Добавить раздел</span>
            </button>
          )}
        </div>
      </main>
    </div>
  );
}