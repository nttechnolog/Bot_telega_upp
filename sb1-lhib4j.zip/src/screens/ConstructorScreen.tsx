import React, { useState, useEffect } from 'react';
import { ArrowLeft, Plus, Bot } from 'lucide-react';
import { Section, Block, BlockType } from '../types';
import { api } from '../services/api';
import { BlockSelector } from '../components/constructor/BlockSelector';
import { BlockEditor } from '../components/constructor/BlockEditor';
import { ConstructorCanvas } from '../components/constructor/ConstructorCanvas';

interface ConstructorScreenProps {
  onBack: () => void;
  appId: string;
  sectionId: string;
  sectionName: string;
}

export function ConstructorScreen({ onBack, appId, sectionId, sectionName }: ConstructorScreenProps) {
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [isAddingBlock, setIsAddingBlock] = useState(false);
  const [editingBlock, setEditingBlock] = useState<Block | null>(null);
  const [draggedBlock, setDraggedBlock] = useState<Block | null>(null);

  useEffect(() => {
    loadBlocks();
  }, [sectionId]);

  const loadBlocks = async () => {
    const response = await api.getSectionBlocks(appId, sectionId);
    if (response.success && response.data) {
      setBlocks(response.data);
    }
  };

  const handleBlockSelect = (type: BlockType) => {
    const newBlock: Block = {
      id: crypto.randomUUID(),
      type,
      order: blocks.length,
      content: {},
      style: {},
      isActive: true
    };
    setEditingBlock(newBlock);
    setIsAddingBlock(false);
  };

  const handleBlockSave = async (block: Block) => {
    if (blocks.find(b => b.id === block.id)) {
      const response = await api.updateBlock(appId, sectionId, block);
      if (response.success) {
        setBlocks(blocks.map(b => b.id === block.id ? block : b));
      }
    } else {
      const response = await api.createBlock(appId, sectionId, block);
      if (response.success) {
        setBlocks([...blocks, block]);
      }
    }
    setEditingBlock(null);
  };

  const handleBlockDelete = async (blockId: string) => {
    if (window.confirm('Вы уверены, что хотите удалить этот блок?')) {
      const response = await api.deleteBlock(appId, sectionId, blockId);
      if (response.success) {
        setBlocks(blocks.filter(b => b.id !== blockId));
      }
    }
  };

  const handleDragStart = (block: Block) => {
    setDraggedBlock(block);
  };

  const handleDragOver = async (e: React.DragEvent, targetBlock: Block) => {
    e.preventDefault();
    if (!draggedBlock || draggedBlock.id === targetBlock.id) return;

    const newBlocks = [...blocks];
    const draggedIndex = blocks.findIndex(b => b.id === draggedBlock.id);
    const targetIndex = blocks.findIndex(b => b.id === targetBlock.id);

    newBlocks.splice(draggedIndex, 1);
    newBlocks.splice(targetIndex, 0, draggedBlock);

    const updatedBlocks = newBlocks.map((block, index) => ({
      ...block,
      order: index
    }));

    const response = await api.updateBlocksOrder(appId, sectionId, updatedBlocks);
    if (response.success) {
      setBlocks(updatedBlocks);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-purple-900">
      <div className="absolute inset-0 animate-shimmer pointer-events-none" />
      
      <header className="fixed top-0 w-full bg-purple-900/90 backdrop-blur-lg z-50 border-b border-purple-500/20">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={onBack}
                className="p-2 hover:bg-purple-700/50 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-white" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-white">Конструктор</h1>
                <p className="text-sm text-purple-200">{sectionName}</p>
              </div>
            </div>
            <div className="w-12 h-12 relative">
              <Bot className="w-full h-full text-purple-400 animate-spin-slow" />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 pt-24 pb-24">
        {editingBlock ? (
          <BlockEditor
            block={editingBlock}
            onSave={handleBlockSave}
            onCancel={() => setEditingBlock(null)}
          />
        ) : isAddingBlock ? (
          <BlockSelector onSelect={handleBlockSelect} onCancel={() => setIsAddingBlock(false)} />
        ) : (
          <div className="space-y-4">
            <ConstructorCanvas
              blocks={blocks}
              onBlockEdit={setEditingBlock}
              onBlockDelete={handleBlockDelete}
              onDragStart={handleDragStart}
              onDragOver={handleDragOver}
            />
            
            <button
              onClick={() => setIsAddingBlock(true)}
              className="w-full bg-purple-800/30 hover:bg-purple-700/30 rounded-lg border border-purple-500/20 p-4 flex items-center justify-center space-x-2 group transition-all"
            >
              <Plus className="w-5 h-5 text-purple-400 group-hover:text-purple-200" />
              <span className="text-purple-400 group-hover:text-purple-200">Добавить блок</span>
            </button>
          </div>
        )}
      </main>
    </div>
  );
}