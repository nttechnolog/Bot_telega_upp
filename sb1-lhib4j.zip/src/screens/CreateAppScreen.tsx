import React, { useState } from 'react';
import { ArrowLeft, Bot } from 'lucide-react';
import { AppData } from '../types';

interface CreateAppScreenProps {
  onBack: () => void;
  onCreateApp: (data: AppData) => void;
}

export function CreateAppScreen({ onBack, onCreateApp }: CreateAppScreenProps) {
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    isPremium: false
  });
  const [addressError, setAddressError] = useState('');

  const validateAddress = (value: string) => {
    const regex = /^[a-z0-9-]+$/;
    if (!regex.test(value) && value !== '') {
      setAddressError('Допустимы только английские буквы в нижнем регистре, цифры и дефис');
      return false;
    }
    setAddressError('');
    return true;
  };

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.toLowerCase();
    if (validateAddress(value)) {
      setFormData({ ...formData, address: value });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.address) {
      alert('Заполните все обязательные поля');
      return;
    }
    if (!validateAddress(formData.address)) {
      return;
    }

    const newApp: AppData = {
      id: crypto.randomUUID(),
      name: formData.name,
      address: formData.address,
      isPremium: formData.isPremium,
      isFavorite: false,
      createdAt: Date.now()
    };

    onCreateApp(newApp);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-900 via-purple-800 to-purple-900">
      <div className="absolute inset-0 animate-shimmer pointer-events-none" />
      
      <header className="fixed top-0 w-full bg-purple-900/90 backdrop-blur-lg z-50 border-b border-purple-500/20">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <button
                onClick={onBack}
                className="p-2 hover:bg-purple-700/50 rounded-full transition-colors"
              >
                <ArrowLeft className="w-6 h-6 text-white" />
              </button>
              <h1 className="text-xl font-bold text-white">Создать мини-приложение</h1>
            </div>
            <div className="w-12 h-12 relative">
              <Bot className="w-full h-full text-purple-400 animate-spin-slow" />
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 pt-24 pb-16 relative">
        <div className="flex justify-center mb-8">
          <div className="w-20 h-20 rounded-full bg-gradient-to-r from-purple-600/30 to-blue-600/30 flex items-center justify-center animate-pulse">
            <Bot className="w-10 h-10 text-white" />
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="group">
              <label className="block text-sm font-medium text-purple-200 mb-2">
                Название
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-purple-800/30 border border-purple-500/30 rounded-lg px-4 py-3 text-white placeholder-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all group-hover:bg-purple-700/30"
                placeholder="Введите название мини-приложения"
                required
              />
            </div>

            <div className="group">
              <label className="block text-sm font-medium text-purple-200 mb-2">
                Адрес мини-приложения
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={handleAddressChange}
                className={`w-full bg-purple-800/30 border ${addressError ? 'border-red-500' : 'border-purple-500/30'} rounded-lg px-4 py-3 text-white placeholder-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all group-hover:bg-purple-700/30`}
                placeholder="например: my-app"
                required
              />
              {addressError && (
                <p className="text-sm text-red-400 mt-1">{addressError}</p>
              )}
              <p className="text-sm text-purple-400 mt-1">
                Может содержать только латинские символы в нижнем регистре, цифры или дефис
              </p>
            </div>

            <div className="flex items-center justify-between p-4 bg-purple-800/30 rounded-lg border border-purple-500/30 group hover:bg-purple-700/30 transition-all">
              <label htmlFor="isPremium" className="text-sm text-purple-200">
                Премиум приложение
              </label>
              <label className="toggle-switch">
                <input
                  type="checkbox"
                  id="isPremium"
                  checked={formData.isPremium}
                  onChange={(e) => setFormData({ ...formData, isPremium: e.target.checked })}
                />
                <span className="toggle-slider"></span>
              </label>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-600 to-blue-500 hover:from-purple-500 hover:to-blue-400 text-white rounded-lg p-4 font-medium transition-all duration-300 shadow-lg hover:shadow-purple-500/25 relative overflow-hidden group"
          >
            <span className="relative z-10">Создать мини-приложение</span>
            <div className="absolute inset-0 animate-shimmer group-hover:opacity-100 opacity-0 transition-opacity" />
          </button>
        </form>
      </main>
    </div>
  );
}