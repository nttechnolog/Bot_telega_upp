import { CSSProperties } from 'react';

export type Screen = 'home' | 'create' | 'premium' | 'hub' | 'settings' | 'sections' | 'constructor';

export interface AppData {
  id: string;
  name: string;
  address: string;
  isPremium: boolean;
  isFavorite?: boolean;
  createdAt: number;
}

export interface Section {
  id: string;
  name: string;
  slug: string;
  icon?: string;
  isActive: boolean;
  order: number;
  blocks: Block[];
}

export type BlockType = 
  | 'text'
  | 'image'
  | 'button'
  | 'form'
  | 'mainButton'
  | 'auxButton'
  | 'video'
  | 'faq'
  | 'iconText'
  | 'divider'
  | 'shop'
  | 'social'
  | 'carousel'
  | 'audio'
  | 'map'
  | 'timer'
  | 'code';

export interface Block {
  id: string;
  type: BlockType;
  order: number;
  content: any;
  style: CSSProperties;
  isActive: boolean;
}

export interface TextBlock extends Block {
  type: 'text';
  content: {
    text: string;
    fontSize: number;
    fontStyle: string;
    color: string;
    alignment: 'left' | 'center' | 'right';
  };
}

export interface ImageBlock extends Block {
  type: 'image';
  content: {
    url: string;
    alt: string;
    width: number;
    height: number;
    fit: 'cover' | 'contain' | 'fill';
  };
}

// Интерфейсы для API
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

export interface UserApps {
  userId: string;
  apps: AppData[];
}

export interface AppSections {
  appId: string;
  sections: Section[];
}